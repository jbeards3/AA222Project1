#=
        project1.jl -- This is where the magic happens!

    All of your code must either live in this file, or be `include`d here.
=#

#=
    If you want to use packages, please do so up here.
    Note that you may use any packages in the julia standard library
    (i.e. ones that ship with the julia language) as well as Statistics
    (since we use it in the backend already anyway)
=#

# Example:
using LinearAlgebra

#=
    If you're going to include files, please do so up here. Note that they
    must be saved in project1_jl and you must use the relative path
    (not the absolute path) of the file in the include statement.

    [Good]  include("somefile.jl")
    [Bad]   include("/pathto/project1_jl/somefile.jl")
=#

# Example
# include("myfile.jl")


"""
    optimize(f, g, x0, n, prob)

Arguments:
    - `f`: Function to be optimized
    - `g`: Gradient function for `f`
    - `x0`: (Vector) Initial position to start from
    - `n`: (Int) Number of evaluations allowed. Remember `g` costs twice of `f`
    - `prob`: (String) Name of the problem. So you can use a different strategy for each problem. E.g. "simple1", "secret2", etc.

Returns:
    - The location of the minimum
"""

# Will only be logging history of x throughout each iteration since gradient descent method doesn't need f(x),
# plus keeping history of f(x) at each iteration wastes an evaluation, thus reducing the number of iterations
# I can run. Since the number of evaluation doesn't matter for plotting, I will be logging f(x) history there
function optimize(f, g, x0, n, prob)
    if prob == "simple1"
        x_history = optimizer_momentum_decay(f, g, x0, n; alpha = 0.2, beta = 0.8, gamma = 1, p = 0.85)
    elseif prob == "simple2"
        x_history = optimizer_momentum_decay(f, g, x0, n; alpha = 1, beta = 0.9, gamma = 1, p = 0.85)
    elseif prob == "simple3"
        x_history = optimizer_momentum_decay(f, g, x0, n; alpha = 1, beta = 0.9, gamma = 1, p = 0.85)
    elseif prob == "secret1"
        x_history = optimizer_momentum_decay(f, g, x0, n; alpha = 1, beta = 0.9, gamma = 1, p = 0.85)
    elseif prob == "secret2"
        x_history = optimizer_momentum_decay(f, g, x0, n; alpha = 1, beta = 0.9, gamma = 1, p = 0.85)
    end
    x_best = last(x_history)
    return x_best
end

function optimizer_simple(f, g, x0, n, alpha = 0.01, beta = 0.0001)
    x_history = [x0]

    while count(f, g) < n

        x = x_history[end]
        # f_x = f(x)
        g_x = g(x)

        # Calculate local descent
        d = -g_x / norm(g_x)

        # Backtracking Line search
        # while f(x + alpha * d) > f_x + beta * alpha * (g_x⋅d)
        #     alpha *= 0.5
        # end

        # Calculate next design point
        x_next = x_history[end] + alpha * d
        # x_next = x_history[end] - step * g_x

        # Add design point to history of design points
        push!(x_history, x_next)
    end

    return x_history
end

function optimizer_momentum(f, g, x0, n, alpha = 0.01, beta = 0)
    x_history = [x0]
    v = zeros(length(x0))

    while count(f, g) < n
        # Calculate local descent
        g_x = g(x_history[end])
        d = -g_x / norm(g_x)
        v[:] = beta*v + alpha * d

        # Calculate next design point
        x_next = x_history[end] + v

        # Add design point to history of design points
        push!(x_history, x_next)
    end

    return x_history
end

function optimizer_simple_decay(f, g, x0, n, alpha = 0.01, beta = 0.0001, gamma = 1, p = 0.9)
    x_history = [x0]

    while count(f, g) < n

        x = x_history[end]
        # f_x = f(x)
        g_x = g(x)

        # Calculate local descent
        d = -g_x / norm(g_x)

        # Backtracking Line search
        # while f(x + alpha * d) > f_x + beta * alpha * (g_x⋅d)
        #     alpha *= 0.5
        # end

        # Calculate next design point
        x_next = x_history[end] + alpha * gamma * d
        gamma *= p
        # x_next = x_history[end] - step * g_x

        # Add design point to history of design points
        push!(x_history, x_next)
    end

    return x_history
end

function optimizer_momentum_decay(f, g, x0, n; alpha = 0.1, beta = 0.9, gamma = 1, p = 0.75)
    x_history = [x0]
    v = zeros(length(x0))

    while count(f, g) < n
        # Calculate local descent
        g_x = g(x_history[end] + beta * v)
        d = -g_x / norm(g_x)
        v[:] = beta * v + alpha * gamma * d
        gamma *= p

        # Calculate next design point
        x_next = x_history[end] + v

        # Add design point to history of design points
        push!(x_history, x_next)
    end

    return x_history
end
